import Firebase
import FirebaseAuth
import FirebaseFirestore

class FirebaseManager: ObservableObject {
    static let shared = FirebaseManager()
    private init() { }

    @Published var user: User?
    var db = Firestore.firestore()

    func configure() {
        FirebaseApp.configure()
        signInAnonymously()
    }

    private func signInAnonymously() {
        Auth.auth().signInAnonymously { [weak self] authResult, error in
            guard let user = authResult?.user, error == nil else {
                print("Firebase sign-in error: \(error?.localizedDescription ?? "Unknown error")")
                return
            }
            DispatchQueue.main.async {
                self?.user = user
                print("Signed in anonymously with uid: \(user.uid)")
            }
        }
    }

    func fetchGarden(completion: @escaping ([String: Int]) -> Void) {
        guard let uid = user?.uid else { return }
        let gardenRef = db.collection("users").document(uid).collection("garden")

        gardenRef.addSnapshotListener { snapshot, error in
            guard let documents = snapshot?.documents, error == nil else {
                print("Error fetching garden: \(error?.localizedDescription ?? "Unknown")")
                return
            }

            var garden: [String: Int] = [:]
            for doc in documents {
                if let name = doc.data()["name"] as? String,
                   let count = doc.data()["count"] as? Int {
                    garden[name] = count
                }
            }
            completion(garden)
        }
    }

    func updatePlant(name: String, delta: Int) {
        guard let uid = user?.uid else { return }
        let plantRef = db.collection("users").document(uid).collection("garden").document(name)

        plantRef.getDocument { document, error in
            let current = (document?.data()?["count"] as? Int) ?? 0
            let newCount = max(0, current + delta)

            plantRef.setData([
                "name": name,
                "count": newCount
            ])
        }
    }
}
