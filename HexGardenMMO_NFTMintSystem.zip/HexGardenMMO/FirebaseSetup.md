# Firebase Setup for HexGardenMMO

1. Go to [Firebase Console](https://console.firebase.google.com/)
2. Create a new iOS project
3. Register your app (e.g. com.yourname.HexGardenMMO)
4. Download `GoogleService-Info.plist`
5. Drag the file into your Xcode project
6. Enable Firestore and Authentication in the Firebase console
7. Run `pod init` and add Firebase dependencies

For more help, see the official guide: https://firebase.google.com/docs/ios/setup
