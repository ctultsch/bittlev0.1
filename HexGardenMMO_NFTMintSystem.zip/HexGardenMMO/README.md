# HexGardenMMO

HexGardenMMO is a multiplayer iOS game where players build gardens and collect botanical specimens. The game integrates real-world botanical collections via Google Search or museum APIs, allowing institutions to validate themselves and connect their collections to in-game elements.

## Features (MVP)
- Firebase-ready SwiftUI app (authentication + Firestore structure)
- Landscape-only UI
- Real-time garden sync via Firestore
- Specimen reference framework (dummy data for now)
- Institutional verification framework stub

## Planned Features
- Real specimen discovery via Google Programmable Search
- Institutional account badge system
- Real-time MMO map and social features

## Getting Started
1. Download and unzip this Xcode project
2. Set up a Firebase project (instructions in FirebaseSetup.md)
3. Add `GoogleService-Info.plist` to the Xcode project
4. Run on iOS Simulator or real device

