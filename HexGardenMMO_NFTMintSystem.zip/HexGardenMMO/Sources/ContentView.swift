import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView {
            VStack {
                Text("Welcome to HexGardenMMO")
                    .font(.largeTitle)
                    .padding()
                NavigationLink("Enter Garden", destination: GardenView())
            }
        }
    }
}
