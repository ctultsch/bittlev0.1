import Foundation

struct HexRegion: Identifiable, Codable {
    var id: String
    var name: String
    var biome: String
    var minUnlockCost: Int
    var maxHexes: Int
    var rarityMultiplier: Double
    var sponsoredBy: String? = nil
}

let predefinedRegions: [HexRegion] = [
    HexRegion(
        id: "region_na001",
        name: "Eastern Americas",
        biome: "Temperate Forest",
        minUnlockCost: 0,
        maxHexes: 10000,
        rarityMultiplier: 1.0
    ),
    HexRegion(
        id: "region_af002",
        name: "Saharan Belt",
        biome: "Desert",
        minUnlockCost: 100,
        maxHexes: 7500,
        rarityMultiplier: 1.2
    ),
    HexRegion(
        id: "region_as003",
        name: "Austral-Asia",
        biome: "Rainforest",
        minUnlockCost: 200,
        maxHexes: 15000,
        rarityMultiplier: 2.0,
        sponsoredBy: "Kew Gardens"
    ),
    HexRegion(
        id: "region_eu004",
        name: "Northern Europe",
        biome: "Boreal Forest",
        minUnlockCost: 50,
        maxHexes: 8000,
        rarityMultiplier: 1.3
    )
]
