import SwiftUI

struct RegionSelectionView: View {
    @State private var regions = predefinedRegions

    var body: some View {
        List {
            ForEach(regions) { region in
                VStack(alignment: .leading) {
                    Text(region.name)
                        .font(.headline)
                    Text("Biome: \(region.biome)")
                    Text("Unlock Cost: \(region.minUnlockCost) XP")
                    if let sponsor = region.sponsoredBy {
                        Text("🌐 Sponsored by \(sponsor)")
                            .foregroundColor(.green)
                    }
                }
                .padding(.vertical, 8)
            }
        }
        .navigationTitle("Choose Starting Region")
    }
}
