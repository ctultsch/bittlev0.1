import SwiftUI

@main
struct HexGardenMMOApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
