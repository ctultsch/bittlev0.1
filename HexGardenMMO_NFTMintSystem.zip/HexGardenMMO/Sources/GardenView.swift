import SwiftUI

struct GardenView: View {
    @State private var garden: [String: Int] = [:]

    var body: some View {
        VStack {
            Text("Your Garden")
                .font(.title)

            List {
                ForEach(garden.sorted(by: { $0.key < $1.key }), id: \.key) { plant, count in
                    HStack {
                        Text(plant)
                        Spacer()
                        Text("x\(count)")
                        Button("+") {
                            FirebaseManager.shared.updatePlant(name: plant, delta: 1)
                        }
                        Button("-") {
                            FirebaseManager.shared.updatePlant(name: plant, delta: -1)
                        }
                    }
                }
            }

            Button("Add New Plant") {
                let sample = ["Rose", "Tulip", "Fern", "Moss"].randomElement()!
                FirebaseManager.shared.updatePlant(name: sample, delta: 1)
            }
            .padding()
        }
        .navigationBarTitle("Garden", displayMode: .inline)
        .onAppear {
            FirebaseManager.shared.fetchGarden { result in
                self.garden = result
            }
        }
    }
}
