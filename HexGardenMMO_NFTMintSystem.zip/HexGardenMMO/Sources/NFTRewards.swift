import Foundation

struct NFTReward: Identifiable, Codable {
    var id: String
    var title: String
    var description: String
    var imageUrl: String
    var unlockCondition: NFTUnlockCondition
    var mintPriceUSD: Double?
    var maxSupply: Int?
    var category: String
}

struct NFTUnlockCondition: Codable {
    var minVisitorsPerDay: Int
    var isPurchasable: Bool
    var requiresSponsorship: Bool
}

let nftRewardTiers: [NFTReward] = [
    NFTReward(
        id: "nft_leaf_token",
        title: "Collector’s Leaf",
        description: "Awarded for 5+ garden visits in 24 hours.",
        imageUrl: "https://example.com/leaf.png",
        unlockCondition: NFTUnlockCondition(
            minVisitorsPerDay: 5,
            isPurchasable: false,
            requiresSponsorship: false
        ),
        mintPriceUSD: nil,
        maxSupply: nil,
        category: "Engagement"
    ),
    NFTReward(
        id: "nft_herbarium_sketch",
        title: "Herbarium Sketch",
        description: "Unlocked with 15+ daily visits or $10 donation.",
        imageUrl: "https://example.com/sketch.png",
        unlockCondition: NFTUnlockCondition(
            minVisitorsPerDay: 15,
            isPurchasable: true,
            requiresSponsorship: false
        ),
        mintPriceUSD: 10.0,
        maxSupply: 500,
        category: "Art"
    ),
    NFTReward(
        id: "nft_expedition_badge",
        title: "Expedition Badge",
        description: "Awarded for supporting science education globally.",
        imageUrl: "https://example.com/badge.png",
        unlockCondition: NFTUnlockCondition(
            minVisitorsPerDay: 25,
            isPurchasable: true,
            requiresSponsorship: true
        ),
        mintPriceUSD: 50.0,
        maxSupply: 100,
        category: "Donation"
    )
]
